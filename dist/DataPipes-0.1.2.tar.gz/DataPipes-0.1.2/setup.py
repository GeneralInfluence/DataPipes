import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name = 'DataPipes',
    version = '0.1.2',
    author="Sean Moore Gonzalez",
    description="Data PubSub Standard for Algorithm Development",
    long_description=long_description,
    url="https://bitbucket.org/picnicdata/datapipes/src/master/",
    packages = setuptools.find_packages(),
    classifiers=["Data Science :: Algorithm :: Pipeline :: Factory :: Python :: OS Independent"]
)

