"""
Contains the overall factory definition.
"""
import logging
from typing import Callable, Generator, Dict, Any, List

from datapipes._utilities.logger import LOGGER_NAME
from datapipes.base import DataBase, RunnerBase, MathBase

_LOGGER = logging.getLogger(LOGGER_NAME)

class Factory:
    """
    Factory class for data I/O.
    """

    __registry = {}

    @classmethod
    def register(cls, name: str) -> Callable:
        """
        Class method to register DataIO class to the internal registry.  This method
        is intended to be used as a decorator.

        Args:
            name (str): The name of the DataIO class.
        Returns:
            The DataIO class itself.
        """

        def inner_wrapper(wrapped_class: (DataBase,RunnerBase,MathBase)) -> Callable:
            if name in cls.__registry:
                _LOGGER.critical(f'DataIO class {name} already exists. Will be replaced.')

            cls.__registry[name] = wrapped_class

            return wrapped_class

        return inner_wrapper

    @classmethod
    # def create(cls, name:str=None, type:str=None, *args, **kwargs) -> DataBase:
    def create(cls, *args, **kwargs) -> DataBase:
        """
        Factory command to create a DataIO object.  This method gets the appropriate
        DataIO class from the registry and creates an instance of it, while passing
        in the parameters given in ``model_type`` and ``kwargs``.

        Args:
            name (str): The name of the DataIO class to instantiate.
            model_type (str): The name of the model that the data relates to.
            kwargs: Configuration parameters.
        Returns:
            An instance of the DataIO class.
        """
        if len(args) < 2:
            raise NotImplementedError(f"class {name} did not receive the correct inputs")
        args = list(args)
        name = args.pop(0)
        # if len(args) > 1:
        #     type = args.pop(0)

        if name not in cls.__registry:
            raise NotImplementedError(f"class {name} does not exist in the registry")

        _LOGGER.debug(f'    OBJECT INSTANTIATED          | one {name} has been instantiated')

        return cls.__registry[name](*args,**kwargs)
        # return cls.__registry[name](type=type,*args,**kwargs)

