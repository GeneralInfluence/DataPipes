from abc import ABC, abstractmethod
from typing import Callable, Generator, Dict, Any, List

class RunnerBase(ABC):
    """
    Base class for the cmd runner.  All runner class implementations must implement this interface.
    """

    def __init__(self, type:str=None):
        """ Constructor. """
        self._type = type
        pass

    @abstractmethod
    def execute(self, cfg:List[Dict[str, Any]]):
        """ Execute the Runner which starts the application. """
        pass

    @abstractmethod
    def close(self):
        """ Close the Model IO class. """
        pass

class DataBase(ABC):
    """
    Base class for data I/O.  All data I/O class implementations must implement this interface.
    """

    def __init__(self, type:str=None):
        """ Constructor. """
        self._type = type

    @abstractmethod
    def read(self) -> Generator[Dict[str, Any], None, None]:
        """ Stream of individual examples. """
        pass

    @abstractmethod
    def batch_read(self) -> List[Dict[str, Any]]:
        """ Provides all examples in a single batch. """
        pass

    @abstractmethod
    def write(self, data: Dict[str, Any]):
        """ Write an individual example. """
        pass

    @abstractmethod
    def batch_write(self, data: List[Dict[str, Any]]):
        """ Write all examples as a batch. """
        pass

    @abstractmethod
    def close(self):
        """ Close the Data IO class. """
        pass

class MathBase(ABC):
    """
    Base class for model I/O.  All model I/O class implementations must implement this interface.
    """

    def __init__(self, type:str=None):
        """ Constructor. """
        self._type = type

    @abstractmethod
    def data_stream(self) -> Generator[Dict[str, Any], None, None]:
        """
        Stream of individual_manual examples.
        """
        raise NotImplementedError(f'Math.data_stream not implemented for {self._model_type}')

    @abstractmethod
    def batch_data(self) -> List[Dict[str, Any]]:
        """ Provides all examples in a single batch. """
        raise NotImplementedError(f'Math.batch_data not implemented for {self._model_type}')

    @abstractmethod
    def write_stream(self, data: Dict[str, Any]):
        """ Write an individual_manual example. """
        raise NotImplementedError(f'Math.write_stream not implemented for {self._model_type}')

    @abstractmethod
    def batch_write(self, data: List[Dict[str, Any]]):
        """ Write all examples as a batch. """
        raise NotImplementedError(f'Math.batch_write not implemented for {self._model_type}')

    @abstractmethod
    def close(self):
        """ Close the Model IO class. """
        pass
