"""
Contains the model I/O factory and model I/O base class definitions.
"""
from abc import ABCMeta, abstractmethod
import logging
from typing import Callable, Generator, Dict, Any, List

from datapipes._utilities.logger import LOGGER_NAME

_LOGGER = logging.getLogger(LOGGER_NAME)


class RunnerBase(metaclass=ABCMeta):
    """
    Base class for the cmd runner.  All runner class implementations must implement this interface.
    """

    def __init__(self):
        """
        Constructor.
        """
        pass

    @abstractmethod
    def execute(self, cfg: List[Dict[str, Any]]):
        """
        Execute the Runner which starts the application.
        """
        pass

    @abstractmethod
    def close(self):
        """
        Close the Model IO class.
        """
        pass

class RunnerFactory:
    """
    Factory class for ModelIO.
    """
    __registry = {}

    @classmethod
    def register(cls, name: str) -> Callable:
        """
        Factory class for Runner.
        """

        def inner_wrapper(wrapped_class: RunnerBase) -> Callable:
            if name in cls.__registry:
                _LOGGER.critical(f'Runner class {name} already exists. Will be replaced.')

            cls.__registry[name] = wrapped_class

            return wrapped_class

        return inner_wrapper

    @classmethod
    def create(cls, name: str, **kwargs) -> RunnerBase:
        """
        Factory command to create a Runner object.  This method gets the appropriate
        Runner class from the registry and creates an instance of it, while passing
        in the parameters given in ``kwargs``.

        Args:
            name (str): The name of the Runner class to instantiate.
            kwargs: Configuration parameters.
        Returns:
            An instance of the Runner class.
        """
        if name not in cls.__registry:
            raise NotImplementedError(f'Runner class {name} does not exist in the registry')

        return cls.__registry[name](**kwargs)
