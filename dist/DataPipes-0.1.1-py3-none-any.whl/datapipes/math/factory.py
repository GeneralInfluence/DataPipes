"""
Contains the model I/O factory and model I/O base class definitions.
"""
from abc import ABCMeta, abstractmethod
import logging
from typing import Callable, Generator, Dict, Any, List

from datapipes._utilities.logger import LOGGER_NAME

_LOGGER = logging.getLogger(LOGGER_NAME)


class MathBase(metaclass=ABCMeta):
    """
    Base class for model I/O.  All model I/O class implementations must implement this interface.
    """

    def __init__(self, model_type: str):
        """
        Constructor.
        """
        # Q:MP could you elaborate on how model_type is used.
        self._model_type = model_type

    @abstractmethod
    def data_stream(self) -> Generator[Dict[str, Any], None, None]:
        """
        Stream of individual_manual examples.
        """
        raise NotImplementedError(f'Math.data_stream not implemented for {self._model_type}')

    @abstractmethod
    def batch_data(self) -> List[Dict[str, Any]]:
        """
        Provides all examples in a single batch.
        """
        raise NotImplementedError(f'Math.batch_data not implemented for {self._model_type}')

    @abstractmethod
    def write_stream(self, data: Dict[str, Any]):
        """
        Write an individual_manual example.
        """
        raise NotImplementedError(f'Math.write_stream not implemented for {self._model_type}')

    @abstractmethod
    def batch_write(self, data: List[Dict[str, Any]]):
        """
        Write all examples as a batch.
        """
        raise NotImplementedError(f'Math.batch_write not implemented for {self._model_type}')

    @abstractmethod
    def close(self):
        """
        Close the Model IO class.
        """
        pass

class MathFactory:
    """
    Factory class for any set of classes computing results.
    """
    __registry = {}

    @classmethod
    def register(cls, name: str) -> Callable:
        """
        Class method to register Math class to the internal registry.  This method
        is intended to be used as a decorator.

        Args:
            name (str): The name of the Math class.
        Returns:
            The Math class itself.
        """
        def inner_wrapper(wrapped_class: MathBase) -> Callable:
            if name in cls.__registry:
                _LOGGER.critical(f'Math class {name} already exists. Will be replaced.')

            cls.__registry[name] = wrapped_class

            return wrapped_class

        return inner_wrapper

    @classmethod
    def create(cls, name: str, model_type: str, **kwargs) -> MathBase:
        """
        Factory command to create a Math object.  This method gets the appropriate
        Math class from the registry and creates an instance of it, while passing
        in the parameters given in ``kwargs``.

        Args:
            name (str): The name of the Math class to instantiate.
        Returns:
            An instance of the Math class.
        """
        if name not in cls.__registry:
            raise NotImplementedError(f'DataIO class {name} does not exist in the registry')

        return cls.__registry[name](model_type, **kwargs)
