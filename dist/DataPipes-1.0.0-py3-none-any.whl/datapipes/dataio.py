import os, uuid, psycopg2
from abc import ABC, abstractmethod
from typing import Callable, Generator, Dict, Any, List, BinaryIO
from datapipes._utilities.logger import LOGGER_NAME
from datapipes.observer import PubSub, Observer, ConcreteSubject
import logging
import pandas as pd
from types import SimpleNamespace
from datetime import datetime

_LOGGER = logging.getLogger(LOGGER_NAME)

class DataBase(ABC):
    """
    Base class for data I/O.  All data I/O class implementations must implement this interface.
    """

    def __init__(self, type:str=None):
        """ Constructor. """
        self._type = type

    @abstractmethod
    def read(self) -> Generator[Dict[str, Any], None, None]:
        """ Stream of individual examples. """
        pass

    @abstractmethod
    def batch_read(self) -> List[Dict[str, Any]]:
        """ Provides all examples in a single batch. """
        pass

    @abstractmethod
    def data_stream(self) -> Generator[Dict[str, Any], None, None]:
        """
        Stream of individual_manual examples.
        """
        raise NotImplementedError(f'Math.data_stream not implemented for {type(self).__name__}')

    @abstractmethod
    def write(self, data: Dict[str, Any]):
        """ Write an individual example. """
        pass

    @abstractmethod
    def batch_write(self, data: List[Dict[str, Any]]):
        """ Write all examples as a batch. """
        raise NotImplementedError(f'Math.batch_write not implemented for {type(self).__name__}')

    @abstractmethod
    def write_stream(self, data: Dict[str, Any]):
        """ Write an individual_manual example. """
        raise NotImplementedError(f'Math.write_stream not implemented for {type(self).__name__}')

    @abstractmethod
    def close(self):
        """ Close the Data IO class. """
        pass

class DataStrategy(ABC):
    """
    Generic interface for Data Pipeline plugin processes to read and write data.
    Implementation: Inherit this class into your algorithm class to force the interface standard.
    Q: Should this interface directly with the algorithm? Is this the simple gateway and the context is enough?
    """
    @abstractmethod
    def load(cls,context:str,data:Dict) -> Dict:
        pass
    @abstractmethod
    def save(cls,context:str,data:Dict) -> Dict:
        pass

class StrategyCSV(DataStrategy):

    def __init__(self,key,path):
        self.key = key
        self.path = path

    def load(self) -> Dict:
        return self.batch_read(key=self.key,path=self.path)

    def save(self,result:Dict=None) -> Dict:
        return self.batch_write(result)

    def batch_read(self,key=None,path=None) -> Generator:
        """
        Provides all examples in a CSV file in a single batch.
        """
        _LOGGER.debug('   CREATING BATCH             | creating batch from csv file contents: %s', path)
        data = pd.read_csv(os.path.join(path, f'{key}.csv'))
        yield key, data

    def batch_write(self, data:pd.DataFrame=None): #, key:str=None, output_path:str='output', output_name:str=uuid.uuid1()):
        """
        Write all examples as a batch.
        """
        _LOGGER.debug(f'   WRITING CSV                | writing csv file from batch for {self.key}')

        os.makedirs(self.path, exist_ok=True)
        out_path_name = os.path.join(self.path, f'{self.key}.csv')
        data.to_csv( out_path_name, index=False)
        # data.to_csv(os.path.join(self._path, f'{key}.csv'), index=False)

class StrategyPostgres(DataStrategy):
    """
    Thing about these strategies is HOW to make them generic
    """
    _PROVDB = None

    def __init__(self,):
        """
        Initialize with... what?
        We don't want initialization to be context specific...
        The interface will have to accept generic versions of the processes below, each client will pass in the details.
        """

    def execute(self):
        pass

    def _prov_connect():
        """
        instantiates cx to prov db
        """
        global _PROVDB

        if _PROVDB is not None:
            return _PROVDB
        else:
            _LOGGER.debug(f'  CONNECTING TO PROVENANCE DATABASE  | Connecting to Picnic Provenance Database')
            return psycopg2.connect(user='sean@picnicscore.com',
                                    dbname='provenance',
                                    host='35.196.161.37')  # password='password',

    def batch_write(self):
        """
        Write all examples pertaining to key as a batch.
        :param key: the unique key (the corp ID) for the batch and the dataset_id
        :type key: str
        :param data: the batch of data to write
        :type data: Dict[str, Any]
        """
        _LOGGER.debug(f'  PROVENANCE DATABASE WRITE     | writing to Picnic Provenance Database')

        repository = subprocess.check_output(["basename", "`git", "rev-parse", "--show-toplevel`"])
        commit = subprocess.check_output(["git", "describe", "--always"]).strip()
        self._create_row(VERSION=f'{commit}',
                         created_date=datetime.now(),
                         has_individual_manual=True,
                         has_vendor_manual=True,
                         has_industry_manual=True,
                         has_document_manual=True,
                         status='CREATED',
                         description=f'picnic models run with repo: {repository} and version: {commit}',
                         name=f'{repository}/{commit}')

        # self._batch_keys.append(key)

        ##############################################################

    def _create_row(
        VERSION: str,
        created_date: datetime = 'NOW()',  # this ensures always use docker tz if tz not passed in manually
        has_individual_manual: bool = False,
        has_vendor_manual: bool = False,
        has_industry_manual: bool = False,
        has_document_manual: bool = False,
        status: str = 'CREATED',
        description: str = None,
        name: str = None,
        **kwargs,
    ) -> int:
        """
        :param VERSION: the version of downloader
        :type VERSION: str
        :param has_individual: whether or not row has an individual-type data type
        :type has_individual: bool
        :param has_vendor: whether or not row has an vendor-type data type
        :type has_industry: bool
        :param has_industry: whether or not row has an industry-type data type
        :type has_industry: bool
        :param has_document: whether or not row has an document-type data type
        :type has_document: bool
        :param status: CREATED or SUCCESS
        :type status: str
        :param name: the name given to the campaign
        :type name: str
        creates a row in the provdb
        returns the BIGSERIAL id
        """
        id = 0

        sql = '''
               INSERT INTO picnicmodel(
                   major_version, 
                   minor_version,
                   patch_version,
                   created_date,
                   has_individual_manual,
                   has_vendor_manual,
                   has_industry_manual,
                   has_document_manual,
                   status,
                   description,
                   name) 
               VALUES(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s) 
               RETURNING id;
           '''

        major, minor, patch = [int(num) for num in VERSION.split('.')]
        VALUES = (
            major,
            minor,
            patch,
            created_date,
            has_individual_manual,
            has_vendor_manual,
            has_industry_manual,
            has_document_manual,
            status,
            description,
            name,
        )

        with _prov_connect() as conn:
            with conn.cursor() as cursor:
                cursor.execute(sql, VALUES)
                conn.commit()
                id = cursor.fetchone()[0]

        _LOGGER.debug(f'  PROVENANCE ROW CREATED   | created new row with id: {id}')

        return id

    def finish_row(id: int) -> None:
        """
        :param id: the id of the dataset
        :type id: int
        """
        sql = '''
               UPDATE downloader 
               SET completed_date = NOW(),
                   status = 'COMPLETED'
               WHERE id = %s;
           '''
        with _prov_connect() as conn:
            with conn.cursor() as cur:
                cur.execute(sql, (id,))
                conn.commit()

        _LOGGER.debug(f'{id} FINISHED')


class DataContext(DataStrategy): #,Observer,ConcreteSubject):
    """
    The Strategy Context can be used to interpret the
    """

    def __init__(self,_cfg:Dict=None): #,strategy:DataStrategy=None):
        """Initialized to no strategy unless specified."""
        # ConcreteSubject.__init__(self)
        self._cfg = _cfg # SimpleNamespace(**_cfg)
        self.setStrategy(self._cfg['format'])
        self.PubSub = PubSub()
        self.PubSub.pubsub_message = {'type':'spigot_data'}
        self.PubSub.pubsub_message['cfg'] = self._cfg

    def addStrategy(self, strategy:DataStrategy):
        key = self._cfg['key']
        path = self._cfg['path']
        self.strategy = strategy(key,path) # Take a key, path, return a dictionary with a csv?

    def setStrategy(self, strategy:str):
        key = self._cfg['key']  # [type(observer).__name__]
        path = self._cfg['path']  # observer._path ## ???? ##
        if strategy=='csv':
            self.strategy = StrategyCSV(key,path)
        elif strategy=='postgres':
            self.strategy = StrategyPostgres(key,path)
        else:
            raise NotImplementedError(f'Strategy {strategy} not implemented for {type(self).__name__}. Strategy options include: "csv" or "postgres"')
            return 1
        return 0

    def on(self):
        key, data = next(self.load())
        self.PubSub.pubsub_message['data'] = data
        self.notify()
        return 0

    def load(self) -> BinaryIO:
        return self.strategy.load()

    def save(self,result:Dict=None) -> BinaryIO:
        return self.strategy.save(result)

    def notify(self):
        return self.PubSub.notify()

    def update(self, subjectPubSub=None):
        self.strategy.save(subjectPubSub.pubsub_message['data'])