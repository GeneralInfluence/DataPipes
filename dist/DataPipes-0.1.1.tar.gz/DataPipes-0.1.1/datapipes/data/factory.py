"""
Contains the data I/O factory and data I/O base class definitions.
"""
import logging
from abc import ABCMeta, abstractmethod
from typing import Callable, Generator, Dict, Any, List

from datapipes._utilities.logger import LOGGER_NAME

_LOGGER = logging.getLogger(LOGGER_NAME)


class DataBase(metaclass=ABCMeta):
    """
    Base class for data I/O.  All data I/O class implementations must implement this interface.
    """

    def __init__(self):
        """
        Constructor.
        """
        pass

    @abstractmethod
    def read(self) -> Generator[Dict[str, Any], None, None]:
        """
        Stream of individual examples.
        """
        pass

    @abstractmethod
    def batch_read(self) -> List[Dict[str, Any]]:
        """
        Provides all examples in a single batch.
        """
        pass

    @abstractmethod
    def write(self, data: Dict[str, Any]):
        """
        Write an individual example.
        """
        pass

    @abstractmethod
    def batch_write(self, data: List[Dict[str, Any]]):
        """
        Write all examples as a batch.
        """
        pass

    @abstractmethod
    def close(self):
        """
        Close the Data IO class.
        """
        pass


class DataFactory:
    """
    Factory class for data I/O.
    """

    __registry = {}

    @classmethod
    def register(cls, name: str) -> Callable:
        """
        Class method to register DataIO class to the internal registry.  This method
        is intended to be used as a decorator.

        Args:
            name (str): The name of the DataIO class.
        Returns:
            The DataIO class itself.
        """

        def inner_wrapper(wrapped_class: (DataBase,str)) -> Callable:
            if name in cls.__registry:
                _LOGGER.critical(f'DataIO class {name} already exists. Will be replaced.')

            cls.__registry[name] = wrapped_class

            return wrapped_class

        return inner_wrapper

    @classmethod
    def create(cls, name: str, model_type: str, **kwargs) -> DataBase:
        """
        Factory command to create a DataIO object.  This method gets the appropriate
        DataIO class from the registry and creates an instance of it, while passing
        in the parameters given in ``model_type`` and ``kwargs``.

        Args:
            name (str): The name of the DataIO class to instantiate.
            model_type (str): The name of the model that the data relates to.
            kwargs: Configuration parameters.
        Returns:
            An instance of the DataIO class.
        """
        if name not in cls.__registry:
            raise NotImplementedError(f'DataIO class {name} does not exist in the registry')

        return cls.__registry[name](**kwargs)
