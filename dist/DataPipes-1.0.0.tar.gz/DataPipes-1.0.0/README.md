# DataPipes
Simplifying the algorithm development process by eliminating typical glue code.

