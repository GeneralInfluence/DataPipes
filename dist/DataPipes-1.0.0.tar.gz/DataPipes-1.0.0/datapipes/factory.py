"""
Contains the overall factory definition.
"""
import logging, json
from typing import Callable, Dict

from datapipes._utilities.logger import LOGGER_NAME
from datapipes.observer import PubSub, Observer, ConcreteSubject #

_LOGGER = logging.getLogger(LOGGER_NAME)


def setattr_decorator(name):
    def wrapper(K):
        setattr(K, name, eval(name))
        return K
    return wrapper

def update(self):
    return self.PubSub.update()

def notify(self):
    return self.PubSub.notify()

def attach(self):
    return self.PubSub.attach()

def detach(self):
    return self.PubSub.detach()


class Factory:
    """
    Factory class for data I/O.
    """

    __registry = {}
    __temp_obj = None

    # @staticmethod
    # def make_with_mixin(cls, mixin):
    #     class NewClass(cls, mixin): pass
    #
    #     # rename class
    #     NewClass.__name__ = "%s_%s" % (cls.__name__, mixin.__name__)
    #     return NewClass
    #
    # @staticmethod
    # def make_with_mixins(cls, mixins):
    #     for mixin in mixins:
    #         if mixin not in cls.__bases__:
    #             cls.__bases__ = (mixin,) + cls.__bases__
    #         else:
    #             print("Cannot add %s to %s" % (mixin, cls))
    #     return cls

    @staticmethod
    def map_proxy(obj):
        dict = {}

        for k in obj.__dict__.keys():
            dict.update({k: obj.__dict__.get(k)})

        cls_name = str(obj).split(".")[1].split("'")[0]
        dict.update({"__class__": cls_name})

        return dict

    @classmethod
    def register(cls, name:str=None) -> Callable:
        """
        Class method to register DataIO class to the internal registry.  This method
        is intended to be used as a decorator.

        Args:
            name (str): The name of the DataIO class.
        Returns:
            The DataIO class itself.
        """

        def inner_wrapper(wrapped_class) -> Callable:
            if name in cls.__registry:
                _LOGGER.critical(f'DataPipes Factory class {name} already exists. Will be replaced.')

            # final_class = cls.make_with_mixins(wrapped_class, (ConcreteSubject,Observer))
            # temp_class = cls.make_with_mixin(ConcreteSubject,wrapped_class)
            # final_class = cls.make_with_mixin(Observer,temp_class)


            # setattr(wrapped_class, 'update', update)
            # setattr(wrapped_class, 'notify', notify)
            # setattr(wrapped_class, 'attach', attach)
            # setattr(wrapped_class, 'detach', detach)

            cls.__registry[name] = wrapped_class

            return wrapped_class # wrapped_class

        return inner_wrapper

    @classmethod
    def create(cls, *args, **kwargs):
        """
        Factory command to create a DataIO object.  This method gets the appropriate
        DataIO class from the registry and creates an instance of it, while passing
        in the parameters given in ``model_type`` and ``kwargs``.

        Args:
            name (str): The name of the DataIO class to instantiate.
            model_type (str): The name of the model that the data relates to.
            kwargs: Configuration parameters.
        Returns:
            An instance of the DataIO class.
        """
        if len(args) == 0:
            raise NotImplementedError(f"The Factory needs to know which registered class to instantiate.")
        args = list(args)
        name = args.pop(0)

        if name not in cls.__registry:
            raise NotImplementedError(f"class {name} does not exist in the registry")

        # I COULD PUT LOGIC HERE THAT DECIDES WHETHER TO RETURN A WRAPPED OBJECT OR NOT.

        # def dyn_create(obj):
        #     return type(obj["__class__"], (cls._Factory__temp_obj,), obj)

        _LOGGER.debug(f'    OBJECT INSTANTIATED          | one {name} has been instantiated')

        # Here I'm forcing the user to implement a specific constructor interface.
        # People do weird things with their constructors, better to add without disrupting.
        # cls._Factory__temp_obj = cls._Factory__registry[name](*args, **kwargs)
        # CS = json.dumps(cls.map_proxy(PubSub()))
        # cls._Factory__temp_obj = PubSub()
        # CS = json.dumps(cls.map_proxy(cls._Factory__registry[name](*args, **kwargs)))
        # final_obj = json.loads(CS, object_hook=dyn_create)

        registered_obj = cls._Factory__registry[name](*args, **kwargs)
        registered_obj.PubSub = PubSub()
        registered_obj.PubSub.pubsub_message = {'type':type(registered_obj).__name__}
        registered_obj.PubSub.pubsub_message['cfg'] = kwargs
        registered_obj.PubSub.pubsub_message['data'] = None

        return registered_obj # cls._Factory__registry[name](*args,**kwargs) # PubSub(cls._Factory__registry[name](*args,**kwargs))

    # @classmethod
    # def subscribe(cls):
    #     pass
    #
    # @classmethod
    # def unsubscribe(cls):
    #     pass
    #
    # @classmethod
    # def publish(cls, data:Dict=None) -> None:
    #     for observer in cls.__subscribers:
    #         cls.message(observer, data)
    #
    # @classmethod
    # def message(cls, observer:'Observer'=None, data:Dict=None) -> None:
    #     observer.update(data)
    #
    # @classmethod
    # def unpublish(cls):
    #     pass